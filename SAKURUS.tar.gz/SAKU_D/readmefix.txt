SEASON OF SAKURA fix 
=========================
1.Good, you've unzip the file.
2.Put this file in the game's directory
3.Check for SK_01.M with "dir sk_01.*"
4.If exist then ----> Enjoy...

fixed by Edsa M.A (menduk1@idola.net.id)


