Starlight Vega - http://egr.ucoz.org/load/games/egr/starlight_vega_pc_windows/6-1-0-172

Sonic & Knuckles Collection - http://egr.ucoz.org/load/sonic_knuckles_collection_sonic_the_hedgehog_cd_pc_windows/1-1-0-171

Pia Carrot He Youkoso (NTSC-J) - http://egr.ucoz.org/load/ehmuljacija/obrazy_nec_pc_fx_cue_bin/pia_carrot_he_youkoso_ntsc_j_jp_en_versija/25-1-0-159

GZDOOM - http://egr.ucoz.org/load/games/egr/gzdoom/6-1-0-157

First Kiss Story (NTSC-J) - http://egr.ucoz.org/load/games/egr/psx_first_kiss_story_ntsc_j_2cd/6-1-0-154

Lаngrіssеr 1 РС - http://egr.ucoz.org/load/games/egr/langrisser_1_rs/6-1-0-135

Langrisser - Kouki no Matsuei (NTSC-J) - http://egr.ucoz.org/load/ehmuljacija/obrazy_pc_engine_cd_cue_iso/langrisser_kouki_no_matsuei_ntsc_j/23-1-0-112

Der Langrisser FX (NTSC-J) - http://egr.ucoz.org/load/ehmuljacija/obrazy_nec_pc_fx_cue_bin/der_langrisser_fx_ntsc_j/25-1-0-115

Lunar - Eternal Blue (NTSC-U) - http://egr.ucoz.org/load/ehmuljacija/obrazy_sega_cd/lunar_eternal_blue/21-1-0-122

Lunar - The Silver Star (NTSC-U) - http://egr.ucoz.org/load/ehmuljacija/obrazy_sega_cd/lunar_the_silver_star_ntsc_u/21-1-0-123

Nekketsu Kakuto Densetsu 2006 PC - http://egr.ucoz.org/load/nekketsu_kakuto_densetsu_pc/exe/nekketsu_kakuto_densetsu_2006_pc/4-1-0-6
